package Rainbow;

public interface BaseClass {

	public void setup() ;
	public void draw();
	
}
